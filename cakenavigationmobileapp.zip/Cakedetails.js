import React ,{useEffect , useState} from "react"
import {View , Text , Button , ScrollView} from "react-native"
import axios from "axios"
import QRCode from 'react-native-qrcode';
export default function CakeDetails(props){
    var [cakedetails,setCakedetails] = useState({})
    useEffect(()=>{
        axios({
          method:"get",
          url:"https://apifromashu.herokuapp.com/api/cake/"+props.route.params.cakeid
        }).then((response)=>{
          setCakedetails(response.data.data)
        })
      },[])
    return(
       <View>
           <Text>Cake Details Page</Text>
       <ScrollView>
    <Text>{cakedetails.name}</Text>
    <Text>{cakedetails.price}</Text>
    <Text>{cakedetails.flavour}</Text>
    <QRCode
          value={cakedetails.cakeid}
          size={200}
          bgColor='purple'
          fgColor='white'/>
      </ScrollView>  
       </View>
    )
}