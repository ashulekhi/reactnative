import { StatusBar } from 'expo-status-bar';
import React, { useEffect , useState } from 'react';
import { StyleSheet,ScrollView ,Button , Text, View , Image, TextInput } from 'react-native';
import Cake from "./Cake"
import Login from './Login';
import axios from 'axios';
import MyVideo from './MyVideo';
export default function App() {
  let [cakes,setCakes] = useState([])
  useEffect(()=>{
    axios({
      method:"get",
      url:"https://apifromashu.herokuapp.com/api/allcakes"
    }).then((response)=>{
      setCakes(response.data.data)
    })
  },[])
  return (
    <View style={styles.container}>
      <MyVideo />
      <Image style={styles.imagelogo} source={{uri:'https://reactnative.dev/img/tiny_logo.png'}} />
      <Login />
      <ScrollView>
      {cakes.map((each,index)=>{
        return <Cake data={each} key={index} />
      })}
      </ScrollView>
     </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputdesign :{
    height:50,
    width:"80%",
    borderWidth:1
  },
  imagelogo:{
    height:50,
    width:50
  }
});
