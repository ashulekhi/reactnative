import React, { useEffect , useState } from 'react';
import { StyleSheet,ScrollView ,Button , Text, View , Image, TextInput } from 'react-native';
import axios from 'axios';
import MyVideo from './MyVideo';
export default function App() {
  let [videos,setVideos] = useState([])
  useEffect(()=>{
    axios({
      method:"get",
      url:"https://videouploadbyashu.herokuapp.com/allvideos"
    }).then((response)=>{
      setVideos(response.data.data)
    })
  },[])
  return (
    <View style={styles.container}>
      <ScrollView>
      {videos.map((each,index)=>{
        return <MyVideo data={each} key={index} />
      })}
      </ScrollView>
     </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputdesign :{
    height:50,
    width:"80%",
    borderWidth:1
  },
  imagelogo:{
    height:50,
    width:50
  }
});
